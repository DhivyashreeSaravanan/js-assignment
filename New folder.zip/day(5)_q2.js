class User {
    constructor(name, age,email) {
      this.name = name;
      this.age = age;
      this.email = email;
      this.luCoins = 0;  
      this.courses = [];
    }
    login(){
        console.log(`${this.name} has logged in`);
        return this;
    }
    logout(){
        console.log(`${this.name} has logged out`);
        return this;
    } 
    }
    class Moderator extends User{
        constructor(name,age,email){
            super(name,age,email); 
        }
        addCoins(user)
        { user.luCoins+=1;
            console.log(`${user.name} has ${user.luCoins} coins`);
            return this;
         }
         diffCoins(user)
        { user.luCoins-=1;
            console.log(`${user.name} has ${user.luCoins} coins`);
            return this;
            
         }
              
    }
    class Admin extends Moderator{
     addCourse(user,course){
                user.courses.push(course);
                console.log(user);
            }
      diffCourse(user,course) 
      {
      { user.courses.splice(course);
      console.log(user); }
    //   user = user.courses.filter(u =>{
    //       u.course!= user.course;
    //        console.log(user);
    // }) }      
         } }
    let user1 = new User('Deepika',25,'dp@gmail.com')
    user1.login();
    user1.logout();
    let user2 = new User('ranvir',25,'rs@gmail.com');
    user2.login();
    user2.logout();
    let mod = new Moderator("director",23,'director@gmail.com');
    mod.addCoins( user1);
    mod.addCoins( user1);
    mod.diffCoins( user1);
    mod.addCoins( user2);
  let admin= new Admin("bollywood",56,"bolly@gmail.com");
  admin.addCourse(user1,'Python');
  admin.diffCourse(user1,'Python');
   admin.addCourse(user2,'Javascript');
  admin.addCourse(user1,'Javascript');

let shoppingList=["cereals","cheese","butter","wheat flour"];
let shoppingBasket=["vegetable oil","Milk drinks",...shoppingList];
console.log(shoppingList);
console.log(shoppingBasket);


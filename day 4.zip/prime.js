let n=+prompt(" enter interval n ");
for( let j=2;j<=n;j++){
    let count=0;
for( let i=2;i<j;i++)
{  if(j%i==0)
    { count++; 
    break;}
}    
 if(count==0)
 { console.log(j);}
}

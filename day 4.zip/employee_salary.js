let sr =+prompt("enter the sales made by employee");
console.log("let the salary be 10,000")
{if((sr>5000)||(sr<0))
console.log(`The sale rate is 2% and total commission ${0.02*10000 +10000}`)
else if(sr>5000||sr<10000)
console.log(`The sale rate is 5% and total commission ${0.05*10000 +10000}`)
else if(sr>10000|| sr<20000)
console.log(`The sale rate is 7% and total commission ${0.07*10000 +10000}`)
else 
console.log(`The sale rate is 10% and total commission ${0.1*10000 +10000}`); }
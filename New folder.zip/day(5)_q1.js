for(let i=0;i<100;i++) {
    let message = +prompt("take a positive number from the user");
 if(message == "null" || message == null || message == "" )
     { break; }
 else if(message>0)
   { console.log(`positive number declared by the user ${message}`)
   break;}
 else
    continue;} 
  console.log("to get number from number array")  ;
  let arey=[];
  for(let i=0;i<5;i++)
  {
    arey=prompt("enter a number");
    console.log(parseInt(arey)) ;  
      }
console.log(" to filter odd numbers")
let arr = [1,2,3,4,5,6];
let odd = arr.filter(el=>(el%2!==0));
console.log(odd);
console.log(`filtered odd number's cube`);
let oddcube = arr.filter(el=>el%2!==0).map(el=>el**3);
console.log(oddcube);
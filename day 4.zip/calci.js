let a=+prompt("enter 1.add, 2.subtraction,3.Multiplication,4.division,5.square root 6.percentage");
let b=+prompt("enter a  value");
let c=+prompt("enter a value");
switch (a) {
    case 1:
        console.log(`the sum of the following numbers ${b}and ${c}is`)
        b+=c;
        console.log(b);
        break;
    case 2:
        console.log(`the differnce of the following numbers ${b}and ${c}is`)
        b-=c;
        console.log(b);
        break;
    case 3:
        console.log(`the product of the following numbers ${b}and ${c}is`)
        b*=c;
        console.log(b);
        break;
    case 4:
        b/=c;
         console.log(b);
        break;
    case 5:
       console.log(`The sqrt root of given value ${Math.sqrt(b)} and   ${Math.sqrt(c)}`);
       break;  
    case 6:
        console.log(`the percentage of ${b} and ${c} upon 100 is ${b}% ${c}% `);  
        break; 
    default:
        console.log("try again later !")
        break;
}
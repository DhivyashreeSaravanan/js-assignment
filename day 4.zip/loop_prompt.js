
for(let i=0;i<100;i++) {
   let message = +prompt("enter a number greater than 100");
if(message == "null" || message == null || message == "" )
  {console.log("\n");
  break; }
else if(message<100)
  { console.log("input again")
  continue;}
else
   break ;}

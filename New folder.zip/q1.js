let mess=prompt("enter your name");
document.body.style.color = 'grey';
document.write("welcome");
const ctime = document.getElementById('time');

function clock(){
    let date = new Date();
    let time = date.toLocaleTimeString();
    ctime.innerText = time;
}

clock();

const a = document.getElementById('dark');
a.classList.add(document.body.style.backgroundColor = 'white');
const button = document.getElementById('btn');
button.onclick = function changeColor(){
a.classList.toggle(document.body.style.backgroundColor = 'black');

   }
 

let n=+prompt("enter a number ");
function table(){
    for(let i=1;i<11;i++)
   document.write(`<br> ${n}X ${i} =${n*i}`)
    return n;
}
const list = document.querySelector('#list');
console.log(list);
list.innerHTML += `<li>${table()}</li>`;
    
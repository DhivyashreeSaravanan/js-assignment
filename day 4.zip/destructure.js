
let student ={
    name: "helsinki",
    age:24,
    project:
    {
        diceGame: "two player dice game using java script"
    },
}
let {name,age,project:{diceGame}}=student;
console.log(name,age,diceGame);
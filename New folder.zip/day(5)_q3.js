async function some(){
    const response = await fetch('https://jsonplaceholder.typicode.com/posts');
    const data = await response.json();

    console.log(data);
}
some();
let todos = [];

fetch('https://jsonplaceholder.typicode.com/posts')
      .then(responses => responses.json())
      .then(data1 => todos = console.log(data1))
      .catch(err => console.log(err));

  let ask=(question,yes,no) => (confirm(question))? yes(): no();

   let x= ask (
        "Do you agree?" ,
        function() {alert("you agreed.");} ,
        function() {alert("you cancelled the execution.");}
    );

    
    
    
